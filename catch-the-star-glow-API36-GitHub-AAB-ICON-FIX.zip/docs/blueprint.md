# **App Name**: Animatic Pro

## Core Features:

- Project Management: Create, import, and organize animation projects in a project gallery.
- Canvas Setup: Set up canvas size, background (solid, transparent, image), and frames per second.
- Drawing Tools: Pencil, Pen, Brush, Fill, Eraser, Shape, Text, Color Picker, Selection, and Transform tools available for drawing and editing.
- Layer Management: Manage drawing layers for separating elements, adjusting opacity, and locking for editing.
- Timeline Control: Add, duplicate, reorder, and multi-select frames in the timeline for animation sequencing.
- Onion Skinning: Display previous and next frames in red and green for guidance in movement and proportions. AI tool to dynamically control the number of frames displayed based on animation speed.
- Export Options: Export animation as MP4, GIF, PNG sequence, or single frame.

## Style Guidelines:

- Primary color: Vibrant Purple (#A06CD5) to invoke a sense of creativity and innovation.
- Background color: Light Grey (#F0F0F0) for a clean and neutral workspace.
- Accent color: Electric Blue (#7DF9FF) for interactive elements and highlights, drawing attention to key controls and options.
- Body and headline font: 'Inter', a grotesque-style sans-serif for a modern, neutral look, suitable for both headlines and body text.
- Use clean and minimalist icons for tools and functions.
- Workspace divided into top bar, canvas, side toolbar, and bottom timeline for clear navigation.
- Subtle transitions and animations when switching tools or managing frames.