
"use client";

import { useState } from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { Layers3, Pencil, Film, Grip, Palette } from 'lucide-react';
import { Toolbar } from './toolbar';
import { LayerPanel } from './layer-panel';
import { Timeline } from './timeline';
import { ToolOptionsPanel } from './tool-options-panel';
import type { Tool, ToolOptions } from "./editor-client";
import type { Layer } from './canvas-view';

type ActiveTab = 'tools' | 'layers' | 'timeline' | 'options' | null;

type MobileToolbarProps = {
  activeTool: Tool;
  onToolSelect: (toolId: Tool) => void;
  toolOptions: ToolOptions;
  onToolOptionsChange: (newOptions: Partial<ToolOptions>) => void;
  layers: Layer[];
  setLayers: React.Dispatch<React.SetStateAction<Layer[]>>;
  activeLayerId: string | null;
  setActiveLayerId: (id: string) => void;
  projectId: string;
};

export function MobileToolbar({ 
  activeTool, 
  onToolSelect, 
  toolOptions, 
  onToolOptionsChange,
  layers,
  setLayers,
  activeLayerId,
  setActiveLayerId,
  projectId,
}: MobileToolbarProps) {
  const [activeTab, setActiveTab] = useState<ActiveTab>(null);

  const tabs: { id: ActiveTab; icon: React.ElementType; label: string }[] = [
    { id: 'tools', icon: Pencil, label: 'Tools' },
    { id: 'layers', icon: Layers3, label: 'Layers' },
    { id: 'timeline', icon: Film, label: 'Timeline' },
    { id: 'options', icon: Palette, label: 'Options' },
  ];

  const activeTabLabel = tabs.find(tab => tab.id === activeTab)?.label;

  const renderContent = () => {
    switch (activeTab) {
      case 'tools':
        return <Toolbar activeTool={activeTool} onToolSelect={(tool) => { onToolSelect(tool); setActiveTab(null); }} />;
      case 'layers':
        return <LayerPanel 
                  layers={layers}
                  setLayers={setLayers}
                  activeLayerId={activeLayerId}
                  setActiveLayerId={setActiveLayerId}
                  projectId={projectId}
               />;
      case 'timeline':
        return <Timeline />;
      case 'options':
        return <ToolOptionsPanel activeTool={activeTool} options={toolOptions} onOptionsChange={onToolOptionsChange} />;
      default:
        return null;
    }
  };

  return (
    <>
      <div className="block sm:hidden border-t bg-background">
        <div className="grid grid-cols-4">
          {tabs.map((tab) => (
            <Button
              key={tab.id}
              variant="ghost"
              className={cn(
                "h-16 rounded-none flex-col gap-1",
                activeTab === tab.id && 'bg-accent text-accent-foreground'
              )}
              onClick={() => setActiveTab(current => current === tab.id ? null : tab.id)}
            >
              <tab.icon className="h-5 w-5" />
              <span className="text-xs">{tab.label}</span>
            </Button>
          ))}
        </div>
      </div>
      <Sheet open={!!activeTab} onOpenChange={(isOpen) => !isOpen && setActiveTab(null)}>
        <SheetContent side="bottom" className="h-2/3 p-0 flex flex-col">
            <SheetHeader className="p-4 pt-2 text-center relative border-b">
                <SheetTitle>{activeTabLabel}</SheetTitle>
                 <div className="absolute top-2 left-1/2 -translate-x-1/2">
                    <Grip className="h-5 w-5 text-muted-foreground" />
                </div>
            </SheetHeader>
            <div className="flex-1 overflow-auto">
                {renderContent()}
            </div>
        </SheetContent>
      </Sheet>
    </>
  );
}

    