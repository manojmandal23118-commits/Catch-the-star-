"use client"

import { Button } from "@/components/ui/button"

export function CreateProjectDialog() {
  return (
    <Button disabled>Create Disabled</Button>
  )
}
