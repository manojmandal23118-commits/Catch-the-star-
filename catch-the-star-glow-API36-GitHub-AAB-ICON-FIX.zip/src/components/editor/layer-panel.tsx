
"use client"

import { useState, useRef } from "react"
import { Eye, EyeOff, Lock, Unlock, Plus, Trash2, Image as ImageIcon } from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { Slider } from "@/components/ui/slider"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import type { Layer } from "./canvas-view"
import { saveLayerData } from "./canvas-view"
import { useToast } from "@/hooks/use-toast"

type LayerPanelProps = {
    layers: Layer[];
    setLayers: React.Dispatch<React.SetStateAction<Layer[]>>;
    activeLayerId: string | null;
    setActiveLayerId: (id: string) => void;
    projectId: string;
}

export function LayerPanel({ layers, setLayers, activeLayerId, setActiveLayerId, projectId }: LayerPanelProps) {
    const [draggedLayerId, setDraggedLayerId] = useState<string | null>(null);
    const [dropTargetId, setDropTargetId] = useState<string | null>(null);
    const layerRefs = useRef<Map<string, HTMLLIElement | null>>(new Map());
    const fileInputRef = useRef<HTMLInputElement>(null);
    const { toast } = useToast();

    const handleAddLayer = () => {
        const newLayer: Layer = {
            id: `layer-${Date.now()}`,
            name: `Layer ${layers.length + 1}`,
            visible: true,
            locked: false,
            opacity: 100,
            canvas: null,
        };

        const tempCanvas = document.createElement('canvas');
        tempCanvas.width = 1920;
        tempCanvas.height = 1080;
        saveLayerData(projectId, newLayer.id, tempCanvas);

        setLayers(currentLayers => [newLayer, ...currentLayers]);
        setActiveLayerId(newLayer.id);
    };

    const handleDeleteLayer = () => {
        if (!activeLayerId || layers.length <= 1) return; 
        
        try {
            localStorage.removeItem(`animatic-pro-layer-${projectId}-${activeLayerId}`);
        } catch (error) {
            console.error("Failed to remove layer data from localStorage", error);
        }

        setLayers(currentLayers => {
            const deletedIndex = currentLayers.findIndex(l => l.id === activeLayerId);
            const filteredLayers = currentLayers.filter(l => l.id !== activeLayerId);
            
            if (filteredLayers.length > 0) {
                const newActiveIndex = Math.max(0, deletedIndex - 1);
                setActiveLayerId(filteredLayers[newActiveIndex].id);
            } else {
                 setActiveLayerId(null);
            }

            return filteredLayers;
        });
    };
    
    const handleImportClick = () => {
        if (!activeLayerId) {
            toast({
                variant: "destructive",
                title: "No active layer",
                description: "Please select a layer before importing an image.",
            });
            return;
        }
        const activeLayer = layers.find(l => l.id === activeLayerId);
        if (activeLayer?.locked) {
            toast({
                variant: "destructive",
                title: "Layer Locked",
                description: `The "${activeLayer.name}" layer is locked. Please unlock it to import an image.`,
            });
            return;
        }
        fileInputRef.current?.click();
    };

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file && activeLayerId) {
            const reader = new FileReader();
            reader.onload = (e) => {
                const img = new Image();
                img.onload = () => {
                    const activeLayer = layers.find(l => l.id === activeLayerId);
                    if (activeLayer && activeLayer.canvas) {
                        const ctx = activeLayer.canvas.getContext('2d');
                        if (ctx) {
                            ctx.clearRect(0, 0, activeLayer.canvas.width, activeLayer.canvas.height);
                            ctx.drawImage(img, 0, 0, activeLayer.canvas.width, activeLayer.canvas.height);
                            saveLayerData(projectId, activeLayerId, activeLayer.canvas);
                             toast({
                                title: "Image Imported",
                                description: `The image has been imported into "${activeLayer.name}".`,
                            });
                        }
                    }
                };
                img.src = e.target?.result as string;
            };
            reader.readAsDataURL(file);
        }
        // Reset file input to allow importing the same file again
        if(event.target) {
            event.target.value = '';
        }
    };


    const updateLayer = (id: string, updates: Partial<Layer>) => {
        setLayers(currentLayers =>
            currentLayers.map(l => (l.id === id ? { ...l, ...updates } : l))
        );
    };

    const handleDragStart = (e: React.DragEvent<HTMLLIElement>, id: string) => {
        setDraggedLayerId(id);
        e.dataTransfer.effectAllowed = 'move';
    };

    const handleDragOver = (e: React.DragEvent<HTMLLIElement>, targetId: string) => {
        e.preventDefault();
        if (draggedLayerId && draggedLayerId !== targetId) {
             setDropTargetId(targetId);
        }
    };
    
    const handleDragLeave = (e: React.DragEvent<HTMLLIElement>) => {
        e.preventDefault();
        setDropTargetId(null);
    };


    const handleDrop = (e: React.DragEvent<HTMLLIElement>, dropId: string) => {
        e.preventDefault();
        if (!draggedLayerId || draggedLayerId === dropId) {
            setDraggedLayerId(null);
            setDropTargetId(null);
            return;
        }

        setLayers(currentLayers => {
            const draggedIndex = currentLayers.findIndex(l => l.id === draggedLayerId);
            const dropIndex = currentLayers.findIndex(l => l.id === dropId);

            if (draggedIndex === -1 || dropIndex === -1) return currentLayers;
            
            const reorderedLayers = [...currentLayers];
            const [draggedItem] = reorderedLayers.splice(draggedIndex, 1);
            reorderedLayers.splice(dropIndex, 0, draggedItem);
            
            return reorderedLayers;
        });

        setDraggedLayerId(null);
        setDropTargetId(null);
    };
    
    const handleDragEnd = () => {
        setDraggedLayerId(null);
        setDropTargetId(null);
    }


  return (
    <div className="flex flex-col h-full bg-sidebar text-sidebar-foreground">
        <div className="p-2 border-b border-sidebar-border">
            <h3 className="font-semibold text-sm">Layers</h3>
        </div>
        <div className="grid grid-cols-2 lg:grid-cols-3 gap-2 p-2">
            <Button variant="outline" size="sm" className="w-full" onClick={handleAddLayer}>
                <Plus className="mr-2 h-4 w-4" /> Add
            </Button>
            <Button 
                variant="outline" 
                size="sm" 
                className="w-full" 
                onClick={handleDeleteLayer}
                disabled={!activeLayerId || layers.length <= 1}
            >
                <Trash2 className="mr-2 h-4 w-4" /> Delete
            </Button>
            <Button variant="outline" size="sm" className="w-full col-span-2 lg:col-span-1" onClick={handleImportClick}>
                <ImageIcon className="mr-2 h-4 w-4" /> Import
            </Button>
            <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="image/*"
                onChange={handleFileChange}
            />
        </div>
        <Separator className="bg-sidebar-border" />
        <TooltipProvider>
        <div className="flex-1 overflow-y-auto px-2">
            <ul className="flex flex-col-reverse gap-2 py-4">
                {layers.map((layer, index) => (
                    <li 
                        key={layer.id} 
                        ref={(node) => layerRefs.current.set(layer.id, node)}
                        onClick={() => setActiveLayerId(layer.id)}
                        draggable={true}
                        onDragStart={(e) => handleDragStart(e, layer.id)}
                        onDragOver={(e) => handleDragOver(e, layer.id)}
                        onDragLeave={handleDragLeave}
                        onDrop={(e) => handleDrop(e, layer.id)}
                        onDragEnd={handleDragEnd}
                        className={cn(
                            "p-2 rounded-md border bg-card hover:bg-accent/50 transition-all duration-150 cursor-pointer relative",
                            activeLayerId === layer.id && "border-primary ring-2 ring-primary",
                            draggedLayerId === layer.id && "opacity-50",
                            dropTargetId === layer.id && "border-blue-500 ring-2 ring-blue-500"
                        )}
                        style={{ zIndex: index }}
                    >
                         {dropTargetId === layer.id && draggedLayerId !== layer.id && (
                            <div className="absolute -top-1 left-0 w-full h-0.5 bg-blue-500" />
                         )}
                        <div className="flex items-center justify-between">
                            <span className="font-medium text-sm truncate">{layer.name}</span>
                            <div className="flex items-center gap-1">
                                <Tooltip>
                                    <TooltipTrigger asChild>
                                        <Button 
                                            variant="ghost" 
                                            size="icon" 
                                            className="h-7 w-7"
                                            onClick={(e) => { e.stopPropagation(); updateLayer(layer.id, { visible: !layer.visible })}}
                                        >
                                            {layer.visible ? <Eye className="h-4 w-4" /> : <EyeOff className="h-4 w-4" />}
                                        </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                        <p>Toggle Visibility</p>
                                    </TooltipContent>
                                </Tooltip>
                                <Tooltip>
                                    <TooltipTrigger asChild>
                                        <Button 
                                            variant="ghost" 
                                            size="icon" 
                                            className="h-7 w-7"
                                            onClick={(e) => { e.stopPropagation(); updateLayer(layer.id, { locked: !layer.locked })}}
                                        >
                                            {layer.locked ? <Lock className="h-4 w-4" /> : <Unlock className="h-4 w-4" />}
                                        </Button>
                                    </TooltipTrigger>
                                    <TooltipContent>
                                        <p>Toggle Lock</p>
                                    </TooltipContent>
                                </Tooltip>
                            </div>
                        </div>
                        <div className="flex items-center gap-3 mt-2">
                            <span className="text-xs text-muted-foreground">Opacity</span>
                            <Slider 
                                value={[layer.opacity]} 
                                onValueChange={(value) => updateLayer(layer.id, { opacity: value[0]})}
                                max={100} 
                                step={1} 
                                onClick={(e) => e.stopPropagation()}
                            />
                        </div>
                    </li>
                ))}
            </ul>
        </div>
        </TooltipProvider>
      </div>
  )
}

    