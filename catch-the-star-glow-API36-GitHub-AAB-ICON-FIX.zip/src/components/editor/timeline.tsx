"use client"

import { PlusSquare, Copy } from "lucide-react"
import {
  ScrollArea,
  ScrollBar,
} from "@/components/ui/scroll-area"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { useState } from "react"

const mockFrames = Array.from({ length: 24 }, (_, i) => ({ id: i + 1 }));

export function Timeline() {
  const [selectedFrame, setSelectedFrame] = useState(1);
  return (
    <div className="p-2 flex flex-col gap-2 h-full">
        <div className="flex items-center gap-2">
            <span className="font-semibold text-sm">Timeline</span>
            <div className="ml-auto flex items-center gap-2">
                <TooltipProvider>
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Button variant="outline" size="sm">
                                <PlusSquare className="h-4 w-4" />
                            </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>Add Frame</p></TooltipContent>
                    </Tooltip>
                    <Tooltip>
                        <TooltipTrigger asChild>
                            <Button variant="outline" size="sm">
                                <Copy className="h-4 w-4" />
                            </Button>
                        </TooltipTrigger>
                        <TooltipContent><p>Duplicate Frame</p></TooltipContent>
                    </Tooltip>
                </TooltipProvider>
            </div>
        </div>
        <ScrollArea className="flex-1 whitespace-nowrap rounded-md border">
          <div className="flex h-full w-max space-x-2 p-2">
            {mockFrames.map((frame) => (
              <button
                key={frame.id}
                onClick={() => setSelectedFrame(frame.id)}
                className={cn(
                  "flex-shrink-0 h-full aspect-[16/9] rounded-md transition-all duration-200",
                  "bg-card border-2",
                  selectedFrame === frame.id ? "border-primary shadow-md" : "border-transparent hover:border-primary/50"
                )}
              >
                <div className="flex flex-col items-center justify-between h-full p-1">
                    <div className="flex-grow w-full bg-secondary/50 rounded-sm">
                        {/* Thumbnail would be here */}
                    </div>
                    <span className="text-xs font-mono mt-1 text-muted-foreground">{frame.id}</span>
                </div>
              </button>
            ))}
          </div>
          <ScrollBar orientation="horizontal" />
        </ScrollArea>
      </div>
  )
}
