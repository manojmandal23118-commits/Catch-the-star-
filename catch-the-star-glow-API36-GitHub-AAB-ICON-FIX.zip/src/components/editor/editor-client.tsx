"use client";

export function EditorPageContents({ projectId }: { projectId: string }) {
    return (
        <div className="flex h-screen w-full items-center justify-center bg-muted/40">
            <h2 className="text-xl font-medium">Editor Content Cleared</h2>
        </div>
    );
}
