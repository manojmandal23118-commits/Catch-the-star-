
"use client"

import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Bold, Italic } from "lucide-react";
import type { Layer } from "./canvas-view";
import { saveLayerData } from "./canvas-view";
import type { ToolOptions } from "./editor-client";

type TextToolDialogProps = {
  isOpen: boolean;
  onClose: () => void;
  position: { x: number, y: number } | null;
  activeLayer: Layer | undefined;
  projectId: string;
  toolOptions: ToolOptions;
};

export function TextToolDialog({
  isOpen,
  onClose,
  position,
  activeLayer,
  projectId,
  toolOptions,
}: TextToolDialogProps) {
  const [text, setText] = useState("");
  const [fontSize, setFontSize] = useState(48);
  const [styles, setStyles] = useState<string[]>([]);

  useEffect(() => {
    if (isOpen) {
      setText("");
      setFontSize(48);
      setStyles([]);
    }
  }, [isOpen]);

  const handleAddText = () => {
    if (!text || !position || !activeLayer?.canvas) {
      onClose();
      return;
    }

    const ctx = activeLayer.canvas.getContext("2d");
    if (!ctx) {
      onClose();
      return;
    }
    
    const isBold = styles.includes("bold");
    const isItalic = styles.includes("italic");
    
    let fontStyle = "";
    if (isItalic) fontStyle += "italic ";
    if (isBold) fontStyle += "bold ";
    
    ctx.font = `${fontStyle} ${fontSize}px sans-serif`;
    ctx.fillStyle = toolOptions.fillColor;
    ctx.textAlign = "left";
    ctx.textBaseline = "top";
    
    ctx.fillText(text, position.x, position.y);
    
    saveLayerData(projectId, activeLayer.id, activeLayer.canvas);
    onClose();
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Add Text</DialogTitle>
        </DialogHeader>
        <div className="grid gap-4 py-4">
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="text-input" className="text-right">
              Text
            </Label>
            <Textarea
              id="text-input"
              value={text}
              onChange={(e) => setText(e.target.value)}
              className="col-span-3"
              placeholder="Type your text here..."
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
            <Label htmlFor="font-size" className="text-right">
              Size
            </Label>
            <Input
              id="font-size"
              type="number"
              value={fontSize}
              onChange={(e) => {
                const value = parseInt(e.target.value, 10);
                setFontSize(isNaN(value) ? 0 : value);
              }}
              className="col-span-3"
            />
          </div>
          <div className="grid grid-cols-4 items-center gap-4">
             <Label className="text-right">Style</Label>
             <ToggleGroup 
                type="multiple"
                variant="outline"
                value={styles}
                onValueChange={(value) => setStyles(value)}
                className="col-span-3 justify-start"
            >
                <ToggleGroupItem value="bold" aria-label="Toggle bold">
                    <Bold className="h-4 w-4" />
                </ToggleGroupItem>
                <ToggleGroupItem value="italic" aria-label="Toggle italic">
                    <Italic className="h-4 w-4" />
                </ToggleGroupItem>
            </ToggleGroup>
          </div>
        </div>
        <DialogFooter>
          <Button onClick={onClose} variant="outline">Cancel</Button>
          <Button onClick={handleAddText}>Add Text</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
