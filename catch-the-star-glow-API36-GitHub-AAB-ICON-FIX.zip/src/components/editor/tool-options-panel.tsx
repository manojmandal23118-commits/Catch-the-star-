"use client"

import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Input } from "@/components/ui/input"
import type { Tool, ToolOptions } from "./editor-client"
import { cn } from "@/lib/utils"

type ToolOptionsPanelProps = {
  activeTool: Tool
  options: ToolOptions
  onOptionsChange: (newOptions: Partial<ToolOptions>) => void
  className?: string
}

export function ToolOptionsPanel({
  activeTool,
  options,
  onOptionsChange,
  className,
}: ToolOptionsPanelProps) {
  const showStrokeColor = ["pencil", "pen", "brush", "shape", "text"].includes(activeTool);
  const showStrokeWidth = ["pencil", "pen", "brush", "eraser", "shape"].includes(activeTool);
  const showFillColor = ["fill", "shape", "text"].includes(activeTool);

  if (!showStrokeColor && !showStrokeWidth && !showFillColor) {
    return (
        <div className={cn("p-4 flex items-center justify-center w-full", className)}>
            <p className="text-sm text-muted-foreground">No options for this tool</p>
        </div>
    );
  }

  return (
    <div className={cn("p-4 flex flex-col sm:flex-row items-center gap-4 sm:gap-6 w-full", className)}>
      {showStrokeWidth && (
        <div className="flex items-center gap-2 w-full sm:w-40">
          <Label htmlFor="stroke-width" className="text-sm">Size</Label>
          <Slider
            id="stroke-width"
            min={1}
            max={100}
            step={1}
            value={[options.strokeWidth]}
            onValueChange={(value) => onOptionsChange({ strokeWidth: value[0] })}
            className="flex-1"
          />
        </div>
      )}
      {showStrokeColor && (
        <div className="flex items-center gap-2">
          <Label htmlFor="stroke-color" className="text-sm">Stroke</Label>
          <Input
            id="stroke-color"
            type="color"
            value={options.strokeColor}
            onChange={(e) => onOptionsChange({ strokeColor: e.target.value })}
            className="w-10 h-10 p-1"
          />
        </div>
      )}
      {showFillColor && (
        <div className="flex items-center gap-2">
          <Label htmlFor="fill-color" className="text-sm">Fill</Label>
          <Input
            id="fill-color"
            type="color"
            value={options.fillColor}
            onChange={(e) => onOptionsChange({ fillColor: e.target.value })}
            className="w-10 h-10 p-1"
          />
        </div>
      )}
    </div>
  )
}
