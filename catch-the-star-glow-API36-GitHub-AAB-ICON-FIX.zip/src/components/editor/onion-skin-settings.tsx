"use client"

import { useState, useEffect } from "react"
import { Wand2 } from "lucide-react"

import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Label } from "@/components/ui/label"
import { Slider } from "@/components/ui/slider"
import { Button } from "@/components/ui/button"
import { useToast } from "@/hooks/use-toast"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "../ui/select"

type AnimationSpeed = "slow" | "normal" | "fast" | "very-fast";

type OnionSkinSettingsProps = {
  fps: number;
  previousFrames: number;
  nextFrames: number;
  onValuesChange: (values: { prev: number, next: number }) => void;
  onSuggestion: (speed: AnimationSpeed) => Promise<{prev: number, next: number} | null>;
};

export function OnionSkinSettings({ 
  fps,
  previousFrames,
  nextFrames,
  onValuesChange,
  onSuggestion
}: OnionSkinSettingsProps) {
  const [animationSpeed, setAnimationSpeed] = useState<AnimationSpeed>("normal");
  const [isSuggesting, setIsSuggesting] = useState(false);

  const handleSuggestion = async () => {
    setIsSuggesting(true);
    await onSuggestion(animationSpeed);
    setIsSuggesting(false);
  }
  
  return (
    <Popover>
      <PopoverTrigger asChild>
        <Button variant="ghost" size="sm">Onion Skin</Button>
      </PopoverTrigger>
      <PopoverContent className="w-80">
        <div className="grid gap-4">
          <div className="space-y-2">
            <h4 className="font-medium leading-none">Onion Skinning</h4>
            <p className="text-sm text-muted-foreground">
              Adjust the visibility of previous and next frames.
            </p>
          </div>
          <div className="grid gap-2">
            <div className="grid grid-cols-3 items-center gap-4">
              <Label htmlFor="previous-frames">Previous</Label>
              <Slider
                id="previous-frames"
                value={[previousFrames]}
                onValueChange={(value) => onValuesChange({prev: value[0], next: nextFrames})}
                max={10}
                step={1}
                className="col-span-2"
              />
            </div>
            <div className="grid grid-cols-3 items-center gap-4">
              <Label htmlFor="next-frames">Next</Label>
              <Slider
                id="next-frames"
                value={[nextFrames]}
                onValueChange={(value) => onValuesChange({prev: previousFrames, next: value[0]})}
                max={10}
                step={1}
                className="col-span-2"
              />
            </div>
          </div>
          <div className="grid gap-2">
            <Label htmlFor="animation-speed">Animation Speed</Label>
            <Select onValueChange={(value: AnimationSpeed) => setAnimationSpeed(value)} defaultValue={animationSpeed}>
                <SelectTrigger id="animation-speed">
                    <SelectValue placeholder="Select speed" />
                </SelectTrigger>
                <SelectContent>
                    <SelectItem value="slow">Slow</SelectItem>
                    <SelectItem value="normal">Normal</SelectItem>
                    <SelectItem value="fast">Fast</SelectItem>
                    <SelectItem value="very-fast">Very Fast</SelectItem>
                </SelectContent>
            </Select>
          </div>
          <Button onClick={handleSuggestion} disabled={isSuggesting}>
            <Wand2 className="mr-2 h-4 w-4" />
            {isSuggesting ? "Thinking..." : "Get AI Suggestion"}
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  )
}
