"use client";

import { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from '@/components/ui/carousel';
import Image from 'next/image';

const tutorialSteps = [
  {
    title: 'স্বাগতম!',
    description:
      'Animatic Pro-তে আপনাকে স্বাগতম! এই টিউটোরিয়ালটি আপনাকে অ্যাপের মূল বৈশিষ্ট্যগুলো বুঝতে সাহায্য করবে।',
    image: 'https://picsum.photos/seed/tut1/800/450',
    imageHint: 'welcome animation',
  },
  {
    title: 'টুলবার পরিচিতি',
    description:
      'স্ক্রিনের উপরের অংশে আপনি টুল অপশন দেখতে পাবেন। পেন্সিল, ইরেজার, রঙ এবং আকার পরিবর্তন করার জন্য এই অপশনগুলো ব্যবহার করুন।',
    image: 'https://picsum.photos/seed/tut2/800/450',
    imageHint: 'toolbar tools',
  },
  {
    title: 'ক্যানভাসে আঁকা',
    description:
      'টুলবার থেকে আপনার পছন্দের টুল (যেমন পেন্সিল) নির্বাচন করুন এবং ক্যানভাসের উপর মাউস ক্লিক করে আঁকা শুরু করুন।',
    image: 'https://picsum.photos/seed/tut3/800/450',
    imageHint: 'drawing hand',
  },
  {
    title: 'লেয়ার প্যানেল',
    description:
      'বাঁদিকের লেয়ার প্যানেল থেকে নতুন লেয়ার যুক্ত করুন, লেয়ার মুছুন, লক করুন অথবা স্বচ্ছতা পরিবর্তন করুন। সক্রিয় লেয়ারে একটি নীল বর্ডার থাকবে।',
    image: 'https://picsum.photos/seed/tut4/800/450',
    imageHint: 'layers panel',
  },
  {
    title: 'রঙ নির্বাচন',
    description:
      'কালার পিকার টুলটি (Pipette) ব্যবহার করে ক্যানভাস থেকে যেকোনো রঙ সরাসরি নির্বাচন করুন। এটি আপনার স্ট্রোক এবং ফিল কালার পরিবর্তন করে দেবে।',
    image: 'https://picsum.photos/seed/tut5/800/450',
    imageHint: 'color picker',
  },
  {
    title: 'টাইমলাইন',
    description:
      'নিচের টাইমলাইনটি আপনার অ্যানিমেশনের ফ্রেমগুলো পরিচালনা করার জন্য। এখানে আপনি নতুন ফ্রেম যুক্ত করতে, নকল করতে বা মুছতে পারবেন।',
    image: 'https://picsum.photos/seed/tut6/800/450',
    imageHint: 'animation timeline',
  },
  {
    title: 'প্রজেক্ট এক্সপোর্ট',
    description:
      'আপনার কাজ শেষ হলে, উপরের ডানদিকে থাকা "Export" বাটনে ক্লিক করে আপনার অ্যানিমেশনটি ভিডিও বা GIF হিসেবে সংরক্ষণ করতে পারবেন।',
    image: 'https://picsum.photos/seed/tut7/800/450',
    imageHint: 'export options',
  },
];

type TutorialDialogProps = {
  open: boolean;
  onOpenChange: (open: boolean) => void;
};

export function TutorialDialog({ open, onOpenChange }: TutorialDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>Animatic Pro টিউটোরিয়াল</DialogTitle>
          <DialogDescription>
            অ্যাপটি কীভাবে ব্যবহার করবেন তা ধাপে ধাপে জেনে নিন।
          </DialogDescription>
        </DialogHeader>
        <Carousel className="w-full">
          <CarouselContent>
            {tutorialSteps.map((step, index) => (
              <CarouselItem key={index}>
                <div className="p-1">
                  <div className="flex aspect-video items-center justify-center relative overflow-hidden rounded-lg mb-4">
                     <Image
                        src={step.image}
                        alt={step.title}
                        width={800}
                        height={450}
                        className="object-cover"
                        data-ai-hint={step.imageHint}
                      />
                  </div>
                  <h3 className="text-lg font-semibold">{step.title}</h3>
                  <p className="text-sm text-muted-foreground mt-1">
                    {step.description}
                  </p>
                </div>
              </CarouselItem>
            ))}
          </CarouselContent>
          <CarouselPrevious className="absolute left-[-50px] top-1/2 -translate-y-1/2" />
          <CarouselNext className="absolute right-[-50px] top-1/2 -translate-y-1/2" />
        </Carousel>

        <DialogFooter>
          <Button onClick={() => onOpenChange(false)}>শুরু করুন</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
