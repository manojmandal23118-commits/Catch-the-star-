
"use client"

import { useRef, useEffect, useState, createRef, useCallback } from "react"
import { cn } from "@/lib/utils"
import { useToast } from "@/hooks/use-toast"
import type { Project } from "@/lib/types";
import type { Tool, ToolOptions, AnimationSettings } from "./editor-client";

export type Layer = {
    id: string;
    name: string;
    visible: boolean;
    locked: boolean;
    opacity: number;
    canvas: HTMLCanvasElement | null;
}

type CanvasViewProps = {
    projectId: string;
    backgroundColor?: string;
    isTransparent?: boolean;
    backgroundImage?: string;
    activeTool: Tool;
    toolOptions: ToolOptions;
    layers: Layer[];
    setLayers: React.Dispatch<React.SetStateAction<Layer[]>>;
    activeLayerId: string | null;
    onToolOptionsChange: (newOptions: Partial<ToolOptions>) => void;
    isLayerLocked: boolean;
    onInteractionStart: (event: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => void;
    onTextToolActivate: (position: { x: number, y: number }) => void;
    animationSettings: AnimationSettings;
}

function hexToRgb(hex: string) {
    const result = /^#?([a-f\d]{2})([a-f\d]{2})([a-f\d]{2})$/i.exec(hex);
    return result ? {
        r: parseInt(result[1], 16),
        g: parseInt(result[2], 16),
        b: parseInt(result[3], 16)
    } : null;
}

function rgbToHex(r: number, g: number, b: number) {
    return "#" + ((1 << 24) + (r << 16) + (g << 8) + b).toString(16).slice(1).padStart(6, '0');
}

export const saveLayerData = (projectId: string, layerId: string, canvas: HTMLCanvasElement) => {
    try {
        const dataUrl = canvas.toDataURL();
        localStorage.setItem(`animatic-pro-layer-${projectId}-${layerId}`, dataUrl);

        const savedProjectsString = localStorage.getItem("animatic-pro-projects");
        if (savedProjectsString) {
            const savedProjects: Project[] = JSON.parse(savedProjectsString);
            const projectIndex = savedProjects.findIndex(p => p.id === projectId);
            if (projectIndex !== -1) {
                savedProjects[projectIndex].lastModified = new Date().toISOString();
                localStorage.setItem("animatic-pro-projects", JSON.stringify(savedProjects));
            }
        }
    } catch (error) {
        console.error("Failed to save layer data to localStorage", error);
    }
};

export const loadLayerData = (layerId: string, canvas: HTMLCanvasElement, projectId: string) => {
    try {
        const dataUrl = localStorage.getItem(`animatic-pro-layer-${projectId}-${layerId}`);
        const context = canvas.getContext('2d');
        if (context) {
            context.clearRect(0, 0, canvas.width, canvas.height);
            if (dataUrl) {
                const img = new Image();
                img.onload = () => {
                    context.drawImage(img, 0, 0, canvas.width, canvas.height);
                };
                img.src = dataUrl;
            }
        }
    } catch (error) {
        console.error("Failed to load layer data from localStorage", error);
    }
};

export function CanvasView({ 
    projectId,
    backgroundColor = '#FFFFFF', 
    isTransparent = false,
    backgroundImage,
    activeTool,
    toolOptions,
    layers,
    setLayers,
    activeLayerId,
    onToolOptionsChange,
    isLayerLocked,
    onInteractionStart,
    onTextToolActivate,
    animationSettings,
}: CanvasViewProps) {
    const containerRef = useRef<HTMLDivElement>(null);
    const [isDrawing, setIsDrawing] = useState(false);
    const { toast } = useToast();
    
    const toolOptionsRef = useRef(toolOptions);
    useEffect(() => {
        toolOptionsRef.current = toolOptions;
    }, [toolOptions]);

    const canvasRefs = useRef<Map<string, React.RefObject<HTMLCanvasElement>>>(new Map());

    useEffect(() => {
        const newRefs = new Map<string, React.RefObject<HTMLCanvasElement>>();
        let refsChanged = false;
        layers.forEach(layer => {
            let ref = canvasRefs.current.get(layer.id);
            if (!ref) {
                ref = createRef<HTMLCanvasElement>();
                refsChanged = true;
            }
            newRefs.set(layer.id, ref);
        });
        
        const currentKeys = Array.from(canvasRefs.current.keys());
        const newKeys = Array.from(newRefs.keys());
        
        if (refsChanged || currentKeys.length !== newKeys.length || !currentKeys.every((key, index) => key === newKeys[index])) {
            canvasRefs.current = newRefs;
        }
    }, [layers]);
    
    useEffect(() => {
        const updatedLayers = layers.map((layer) => {
            const canvas = canvasRefs.current.get(layer.id)?.current;
            if (canvas && !layer.canvas) {
                loadLayerData(layer.id, canvas, projectId);
                return { ...layer, canvas };
            }
            return layer;
        });

        const hasChanged = layers.some((l, i) => l.canvas !== updatedLayers[i].canvas);
        if (hasChanged) {
            setLayers(updatedLayers);
        }
    }, [layers, projectId, setLayers, animationSettings.width, animationSettings.height]);
    
    const getActiveContext = () => {
        if (!activeLayerId) return null;
        const activeCanvas = canvasRefs.current.get(activeLayerId)?.current;
        if (!activeCanvas) return null;
        
        return activeCanvas.getContext("2d");
    }

    const getCoords = (event: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
        const container = containerRef.current;
        if (!container) return { x: 0, y: 0 };

        const rect = container.getBoundingClientRect();
        const clientX = 'touches' in event ? event.touches[0].clientX : event.clientX;
        const clientY = 'touches' in event ? event.touches[0].clientY : event.clientY;

        return {
            x: clientX - rect.left,
            y: clientY - rect.top,
        };
    }
    
    const applyBrushPattern = (ctx: CanvasRenderingContext2D) => {
        const { brushPattern, quality } = animationSettings;
        if (brushPattern === 'dashed') {
            ctx.setLineDash([15, 5]);
        } else if (brushPattern === 'dotted') {
            ctx.setLineDash([2, 8]);
        } else {
            ctx.setLineDash([]);
        }
        // Quality can affect line smoothness or opacity here if needed
        ctx.globalAlpha = 0.5 + (quality / 200); 
    }

    const floodFill = (ctx: CanvasRenderingContext2D, startX: number, startY: number, fillColor: { r: number, g: number, b: number }) => {
        const canvas = ctx.canvas;
        const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
        const data = imageData.data;
        const startPos = (startY * canvas.width + startX) * 4;
        const startR = data[startPos];
        const startG = data[startPos + 1];
        const startB = data[startPos + 2];
        const startA = data[startPos + 3];

        if (fillColor.r === startR && fillColor.g === startG && fillColor.b === startB && startA === 255) {
            return;
        }
        
        const pixelStack = [[startX, startY]];

        while(pixelStack.length) {
            const newPos = pixelStack.pop();
            if (!newPos) continue;

            let x = newPos[0];
            let y = newPos[1];
            let pixelPos = (y * canvas.width + x) * 4;

            while(y-- >= 0 && matchStartColor(pixelPos)) {
                pixelPos -= canvas.width * 4;
            }
            pixelPos += canvas.width * 4;
            ++y;

            let reachLeft = false;
            let reachRight = false;

            while(y++ < canvas.height - 1 && matchStartColor(pixelPos)) {
                colorPixel(pixelPos);

                if (x > 0) {
                    if (matchStartColor(pixelPos - 4)) {
                        if (!reachLeft) {
                            pixelStack.push([x - 1, y]);
                            reachLeft = true;
                        }
                    } else if (reachLeft) {
                        reachLeft = false;
                    }
                }

                if (x < canvas.width - 1) {
                    if (matchStartColor(pixelPos + 4)) {
                        if (!reachRight) {
                            pixelStack.push([x + 1, y]);
                            reachRight = true;
                        }
                    } else if (reachRight) {
                        reachRight = false;
                    }
                }
                pixelPos += canvas.width * 4;
            }
        }

        ctx.putImageData(imageData, 0, 0);

        function matchStartColor(pixelPos: number) {
            return data[pixelPos] === startR && data[pixelPos+1] === startG && data[pixelPos+2] === startB && data[pixelPos+3] === startA;
        }

        function colorPixel(pixelPos: number) {
            data[pixelPos] = fillColor.r;
            data[pixelPos+1] = fillColor.g;
            data[pixelPos+2] = fillColor.b;
            data[pixelPos+3] = 255;
        }
    }


    const startDrawing = (event: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
        const context = getActiveContext();
        if (!context || isLayerLocked) return;

        setIsDrawing(true);
        const { x, y } = getCoords(event);
        const canvas = context.canvas;
        const scaleX = canvas.width / canvas.getBoundingClientRect().width;
        const scaleY = canvas.height / canvas.getBoundingClientRect().height;

        const canvasX = x * scaleX;
        const canvasY = y * scaleY;
        
        context.lineCap = "round";
        context.lineJoin = "round";
        context.strokeStyle = toolOptionsRef.current.strokeColor;
        context.lineWidth = toolOptionsRef.current.strokeWidth;

        applyBrushPattern(context);

        if (activeTool === 'eraser') {
            context.globalCompositeOperation = 'destination-out';
            context.setLineDash([]); // Eraser is always solid
        } else {
            context.globalCompositeOperation = 'source-over';
        }

        context.beginPath();
        context.moveTo(canvasX, canvasY);
    };

    const draw = (event: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
        if (!isDrawing || isLayerLocked) return;
        const context = getActiveContext();
        if (!context) return;
        
        context.strokeStyle = toolOptionsRef.current.strokeColor;
        context.lineWidth = toolOptionsRef.current.strokeWidth;

        const { x, y } = getCoords(event);
        const canvas = context.canvas;
        const scaleX = canvas.width / canvas.getBoundingClientRect().width;
        const scaleY = canvas.height / canvas.getBoundingClientRect().height;
        const canvasX = x * scaleX;
        const canvasY = y * scaleY;

        context.lineTo(canvasX, canvasY);
        context.stroke();
    };

    const stopDrawing = () => {
        const context = getActiveContext();
        if (isDrawing && context) {
            context.closePath();
            if (activeLayerId) {
                saveLayerData(projectId, activeLayerId, context.canvas);
            }
        }
        setIsDrawing(false);
    };
    
    const handleCanvasClick = (event: React.MouseEvent<HTMLDivElement>) => {
        if(isLayerLocked) return;

        const context = getActiveContext();
        if (!context) return; 

        const { x, y } = getCoords(event);
        const canvas = context.canvas;
        const scaleX = canvas.width / canvas.getBoundingClientRect().width;
        const scaleY = canvas.height / canvas.getBoundingClientRect().height;

        const canvasX = Math.round(x * scaleX);
        const canvasY = Math.round(y * scaleY);
        
        if (activeTool === 'fill') {
            const fillColor = hexToRgb(toolOptionsRef.current.fillColor);
            if (fillColor) {
                floodFill(context, canvasX, canvasY, fillColor);
                if (activeLayerId) {
                    saveLayerData(projectId, activeLayerId, context.canvas);
                }
            }
            return;
        }

        if (activeTool === 'picker') {
            let pickedColor: string | null = null;
            for (let i = layers.length - 1; i >= 0; i--) {
                const layer = layers[i];
                if (layer.visible && layer.canvas) {
                    const ctx = layer.canvas.getContext('2d');
                    if (ctx) {
                        const pixel = ctx.getImageData(canvasX, canvasY, 1, 1).data;
                        if (pixel[3] > 0) {
                            pickedColor = rgbToHex(pixel[0], pixel[1], pixel[2]);
                            break;
                        }
                    }
                }
            }
            if (pickedColor === null && !isTransparent) {
                const bgRgb = hexToRgb(backgroundColor);
                if (bgRgb) {
                    pickedColor = rgbToHex(bgRgb.r, bgRgb.g, bgRgb.b);
                }
            }

            if (pickedColor) {
                onToolOptionsChange({ strokeColor: pickedColor, fillColor: pickedColor });
                 toast({
                    title: "Color Picked",
                    description: `Set active color to ${pickedColor}`,
                });
            }
        }
        
        if (activeTool === 'text') {
            onTextToolActivate({ x: canvasX, y: canvasY });
        }
    };
    
    const handleMouseDown = (event: React.MouseEvent<HTMLDivElement>) => {
        onInteractionStart(event);
        if (event.button !== 0 || isLayerLocked) return;
        
        const isDrawingTool = ['pencil', 'pen', 'brush', 'eraser'].includes(activeTool);
        
        if (isDrawingTool) {
            startDrawing(event);
        } else {
            handleCanvasClick(event);
        }
    };
    
    const handleTouchStart = (event: React.TouchEvent<HTMLDivElement>) => {
        onInteractionStart(event);
        if (isLayerLocked) return;

        const isDrawingTool = ['pencil', 'pen', 'brush', 'eraser'].includes(activeTool);

        if(isDrawingTool) {
            event.preventDefault();
            startDrawing(event);
        } else {
            const mockMouseEvent = {
                clientX: event.touches[0].clientX,
                clientY: event.touches[0].clientY,
                 getBoundingClientRect: () => containerRef.current!.getBoundingClientRect(),
            } as any;
            handleCanvasClick(mockMouseEvent);
        }
    }
    
    const handleTouchMove = (event: React.TouchEvent<HTMLDivElement>) => {
        if (!isDrawing) return;
        event.preventDefault();
        draw(event);
    }
    
    const handleTouchEnd = () => {
        stopDrawing();
    }
    
    const backgroundStyle = isTransparent 
        ? { backgroundImage: `
            linear-gradient(45deg, #ccc 25%, transparent 25%), 
            linear-gradient(-45deg, #ccc 25%, transparent 25%),
            linear-gradient(45deg, transparent 75%, #ccc 75%),
            linear-gradient(-45deg, transparent 75%, #ccc 75%)`,
            backgroundSize: '20px 20px',
            backgroundPosition: '0 0, 0 10px, 10px -10px, -10px 0px'
        }
        : { backgroundColor };

    return (
        <div 
            ref={containerRef}
            className="relative aspect-video w-full max-w-4xl bg-white shadow-2xl rounded-lg overflow-hidden touch-none" 
            style={backgroundStyle}
            onMouseDown={handleMouseDown}
            onMouseMove={draw}
            onMouseUp={stopDrawing}
            onMouseLeave={stopDrawing}
            onTouchStart={handleTouchStart}
            onTouchMove={handleTouchMove}
            onTouchEnd={handleTouchEnd}
            onTouchCancel={handleTouchEnd}
        >
            {layers.map((layer, index) => (
                <canvas
                    key={layer.id}
                    ref={canvasRefs.current.get(layer.id)}
                    width={animationSettings.width}
                    height={animationSettings.height}
                    className={cn(
                        "absolute top-0 left-0 w-full h-full pointer-events-none",
                         !layer.visible && "hidden"
                    )}
                    style={{ opacity: layer.opacity / 100, zIndex: index }}
                />
            ))}
        </div>
    );
}
