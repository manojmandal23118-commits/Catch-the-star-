
"use-client"

import Link from "next/link"
import {
  Undo2,
  Redo2,
  Download,
  ChevronLeft,
  BookOpen
} from "lucide-react"

import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { OnionSkinSettings } from "./onion-skin-settings"
import { Logo } from "../icons"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { ToolOptionsPanel } from "./tool-options-panel"
import type { Tool, ToolOptions, AnimationSettings } from "./editor-client"
import { AnimationSettingsDialog } from "./animation-settings-dialog"

type TopBarProps = {
    projectName: string;
    fps: number;
    activeTool: Tool;
    toolOptions: ToolOptions;
    onToolOptionsChange: (newOptions: Partial<ToolOptions>) => void;
    previousFrames: number;
    nextFrames: number;
    onOnionSkinChange: (values: {prev: number, next: number}) => void;
    onOnionSkinSuggestion: (speed: 'slow' | 'normal' | 'fast' | 'very-fast') => Promise<{prev: number, next: number} | null>;
    onShowTutorial: () => void;
    animationSettings: AnimationSettings;
    onAnimationSettingsChange: (newSettings: AnimationSettings) => void;
}

export function TopBar({ 
    projectName, 
    fps, 
    activeTool, 
    toolOptions, 
    onToolOptionsChange,
    previousFrames,
    nextFrames,
    onOnionSkinChange,
    onOnionSkinSuggestion,
    onShowTutorial,
    animationSettings,
    onAnimationSettingsChange,
}: TopBarProps) {
  return (
    <header className="p-2 border-b flex items-center justify-between gap-2 h-16 shrink-0 z-10 bg-background">
      <div className="flex items-center gap-2">
        <Button variant="ghost" size="icon" asChild>
            <Link href="/">
                <ChevronLeft className="h-5 w-5" />
            </Link>
        </Button>
        <Logo className="h-7 w-7 text-primary hidden sm:block" />
        <Separator orientation="vertical" className="h-8 mx-2 hidden sm:block"/>
        <h1 className="text-lg font-semibold truncate">{projectName}</h1>
      </div>

      <div className="hidden sm:flex items-center gap-3 justify-center flex-1">
        <ToolOptionsPanel 
            activeTool={activeTool} 
            options={toolOptions} 
            onOptionsChange={onToolOptionsChange}
        />
      </div>
      
      <div className="flex items-center gap-2 sm:gap-3">
        <Button variant="ghost" size="icon" className="h-9 w-9">
          <Undo2 className="h-5 w-5" />
          <span className="sr-only">Undo</span>
        </Button>
        <Button variant="ghost" size="icon" className="h-9 w-9">
          <Redo2 className="h-5 w-5" />
          <span className="sr-only">Redo</span>
        </Button>
        <Separator orientation="vertical" className="h-8 mx-2 hidden sm:flex"/>
        <div className="hidden sm:block">
            <OnionSkinSettings 
                fps={fps} 
                previousFrames={previousFrames}
                nextFrames={nextFrames}
                onValuesChange={onOnionSkinChange}
                onSuggestion={onOnionSkinSuggestion}
            />
        </div>
        <Button variant="ghost" size="sm" onClick={onShowTutorial}>
            <BookOpen className="h-4 w-4 mr-0 sm:mr-2" />
            <span className="hidden sm:inline">Tutorial</span>
        </Button>
      </div>

      <div className="flex items-center gap-2">
        <AnimationSettingsDialog 
          settings={animationSettings} 
          onSettingsChange={onAnimationSettingsChange} 
        />
        <Dialog>
            <DialogTrigger asChild>
                <Button size="sm">
                    <Download className="mr-0 sm:mr-2 h-4 w-4" />
                    <span className="hidden sm:inline">Export</span>
                </Button>
            </DialogTrigger>
            <DialogContent>
                <DialogHeader>
                    <DialogTitle>Export Animation</DialogTitle>
                    <DialogDescription>Choose your desired format to export your masterpiece.</DialogDescription>
                </DialogHeader>
                <div className="grid grid-cols-2 gap-4 py-4">
                    <Button variant="outline" size="lg" className="h-20">MP4 Video</Button>
                    <Button variant="outline" size="lg" className="h-20">Animated GIF</Button>
                    <Button variant="outline" size="lg" className="h-20">PNG Sequence</Button>
                    <Button variant="outline" size="lg" className="h-20">Single Frame</Button>
                </div>
                <DialogFooter>
                    <Button type="submit" disabled>Export Now</Button>
                </DialogFooter>
            </DialogContent>
        </Dialog>
      </div>
    </header>
  )
}
