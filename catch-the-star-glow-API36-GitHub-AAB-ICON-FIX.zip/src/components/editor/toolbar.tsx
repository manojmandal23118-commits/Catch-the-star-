"use client"

import {
  Pencil,
  PenTool,
  Brush,
  PaintBucket,
  Eraser,
  Shapes,
  Type,
  Pipette,
  Lasso,
  Scaling,
} from "lucide-react"

import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip"
import { Button } from "@/components/ui/button"
import { Separator } from "@/components/ui/separator"
import { cn } from "@/lib/utils"
import type { Tool } from "./editor-client";

const tools: { id: Tool; name: string; icon: React.ElementType }[] = [
  { id: "pencil", name: "Pencil", icon: Pencil },
  { id: "pen", name: "Pen", icon: PenTool },
  { id: "brush", name: "Brush", icon: Brush },
  { id: "fill", name: "Fill", icon: PaintBucket },
  { id: "eraser", name: "Eraser", icon: Eraser },
  { id: "shape", name: "Shape / Ruler", icon: Shapes },
  { id: "text", name: "Text", icon: Type },
  { id: "picker", name: "Color Picker", icon: Pipette },
  { id: "selection", name: "Selection", icon: Lasso },
  { id: "transform", name: "Transform", icon: Scaling },
]

type ToolbarProps = {
    activeTool: Tool;
    onToolSelect: (toolId: Tool) => void;
}

export function Toolbar({ activeTool, onToolSelect }: ToolbarProps) {
  return (
    <div className="p-4 w-full">
      <TooltipProvider delayDuration={0}>
        <div className="grid grid-cols-5 sm:grid-cols-6 md:grid-cols-8 gap-2">
            {tools.map((tool) => (
                <Tooltip key={tool.id}>
                    <TooltipTrigger asChild>
                    <Button
                        variant="outline"
                        size="icon"
                        className={cn(
                            "w-full aspect-square h-auto",
                            activeTool === tool.id && "bg-primary text-primary-foreground ring-2 ring-primary ring-offset-2 ring-offset-background"
                        )}
                        onClick={() => onToolSelect(tool.id)}
                    >
                        <tool.icon className="h-6 w-6" />
                    </Button>
                    </TooltipTrigger>
                    <TooltipContent side="top" align="center">
                        <p>{tool.name}</p>
                    </TooltipContent>
                </Tooltip>
            ))}
        </div>
      </TooltipProvider>
    </div>
  )
}
