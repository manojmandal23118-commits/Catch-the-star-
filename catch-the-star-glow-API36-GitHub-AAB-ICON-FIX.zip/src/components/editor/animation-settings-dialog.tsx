
"use client"

import * as React from "react"
import { Settings2 } from "lucide-react"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
  DialogFooter,
} from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Input } from "@/components/ui/input"
import { Slider } from "@/components/ui/slider"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

type AnimationSettings = {
  width: number
  height: number
  quality: number
  brushPattern: 'solid' | 'dashed' | 'dotted'
}

type AnimationSettingsDialogProps = {
  settings: AnimationSettings
  onSettingsChange: (newSettings: AnimationSettings) => void
}

export function AnimationSettingsDialog({ settings, onSettingsChange }: AnimationSettingsDialogProps) {
  const [localSettings, setLocalSettings] = React.useState<AnimationSettings>(settings)

  const handlePresetChange = (preset: string) => {
    let w = localSettings.width
    let h = localSettings.height

    if (preset === "1:1") { w = 640; h = 640 }
    else if (preset === "3:4") { w = 640; h = 480 }
    else if (preset === "9:16") { w = 1280; h = 720 }

    setLocalSettings(prev => ({ ...prev, width: w, height: h }))
  }

  const handleApply = () => {
    onSettingsChange(localSettings)
  }

  return (
    <Dialog>
      <DialogTrigger asChild>
        <Button variant="ghost" size="icon" className="h-9 w-9">
          <Settings2 className="h-5 w-5" />
          <span className="sr-only">Animation Settings</span>
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle>Animation Settings</DialogTitle>
          <DialogDescription>
            অ্যানিমেশনের রেজুলেশন, গুণমান এবং ব্রাশ প্যাটার্ন পরিবর্তন করুন।
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-6 py-4">
          {/* Aspect Ratio Presets */}
          <div className="space-y-3">
            <Label>Aspect Ratio & Resolution</Label>
            <RadioGroup onValueChange={handlePresetChange} className="grid grid-cols-1 gap-2">
              <div className="flex items-center space-x-2 border p-2 rounded-md hover:bg-accent cursor-pointer">
                <RadioGroupItem value="1:1" id="r1" />
                <Label htmlFor="r1" className="flex-1 cursor-pointer">1:1 (LLD) - 640 x 640</Label>
              </div>
              <div className="flex items-center space-x-2 border p-2 rounded-md hover:bg-accent cursor-pointer">
                <RadioGroupItem value="3:4" id="r2" />
                <Label htmlFor="r2" className="flex-1 cursor-pointer">3:4 (LD) - 640 x 480</Label>
              </div>
              <div className="flex items-center space-x-2 border p-2 rounded-md hover:bg-accent cursor-pointer">
                <RadioGroupItem value="9:16" id="r3" />
                <Label htmlFor="r3" className="flex-1 cursor-pointer">9:16 (SD) - 1280 x 720</Label>
              </div>
            </RadioGroup>
          </div>

          {/* Custom Size Inputs */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="width">Width (W)</Label>
              <Input
                id="width"
                type="number"
                value={localSettings.width}
                onChange={(e) => setLocalSettings(prev => ({ ...prev, width: parseInt(e.target.value) || 0 }))}
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="height">Height (H)</Label>
              <Input
                id="height"
                type="number"
                value={localSettings.height}
                onChange={(e) => setLocalSettings(prev => ({ ...prev, height: parseInt(e.target.value) || 0 }))}
              />
            </div>
          </div>

          {/* Speed vs Quality Slider */}
          <div className="space-y-4">
            <div className="flex justify-between text-sm font-medium">
              <span>Speed</span>
              <span>Quality</span>
            </div>
            <Slider
              value={[localSettings.quality]}
              onValueChange={(val) => setLocalSettings(prev => ({ ...prev, quality: val[0] }))}
              max={100}
              step={1}
            />
          </div>

          {/* Brush Pattern Select */}
          <div className="space-y-2">
            <Label htmlFor="brush-pattern">Brush Pattern</Label>
            <Select 
              value={localSettings.brushPattern} 
              onValueChange={(val: any) => setLocalSettings(prev => ({ ...prev, brushPattern: val }))}
            >
              <SelectTrigger id="brush-pattern">
                <SelectValue placeholder="Select pattern" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="solid">Solid</SelectItem>
                <SelectItem value="dashed">Dashed</SelectItem>
                <SelectItem value="dotted">Dotted</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button onClick={handleApply} className="w-full">Apply Settings</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  )
}
