/**
 * Shared types cleared.
 */

export type Project = {
  id: string;
  name: string;
};
