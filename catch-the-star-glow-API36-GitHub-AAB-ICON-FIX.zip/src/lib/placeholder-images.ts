import data from './placeholder-images.json';

// This file is now deprecated for project data.
// We keep it for potential future use with other placeholder images.

export type ImagePlaceholder = {
  id: string;
  description: string;
  imageUrl: string;
  imageHint: string;
};

export const PlaceHolderImages: ImagePlaceholder[] = data.placeholderImages;
