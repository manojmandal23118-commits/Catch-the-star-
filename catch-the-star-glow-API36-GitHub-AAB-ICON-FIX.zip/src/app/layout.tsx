import type { Metadata } from 'next';
import './globals.css';

export const metadata: Metadata = {
  title: 'Catch The Star Glow',
  description: 'Catch The Star Glow offline game.',
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <body>
        {children}
      </body>
    </html>
  );
}
