'use client';

import React, { useState, useEffect, useRef } from 'react';

export default function CatchTheStarGlowGame() {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const [gameState, setGameState] = useState<'home' | 'playing' | 'levels' | 'shop' | 'settings' | 'victory'>('home');
  const [currentLevel, setCurrentLevel] = useState<number>(1);
  const [highestUnlockedLevel, setHighestUnlockedLevel] = useState<number>(1);
  const [soundEnabled, setSoundEnabled] = useState<boolean>(true);
  const [selectedColor, setSelectedColor] = useState<string>('#ff1a1a');
  const [isMounted, setIsMounted] = useState<boolean>(false);
  const [lives, setLives] = useState<number>(0);

  const audioCtxRef = useRef<AudioContext | null>(null);
  const bgmIntervalRef = useRef<any>(null);

  const ballColors = [
    { name: 'Classic Red Leather', color: '#ff1a1a', glow: '#ff0000' },
    { name: 'White Kookaburra Night', color: '#ffffff', glow: '#e0f7fa' },
    { name: 'Pink Day-Night Match', color: '#ff00aa', glow: '#ff66cc' },
    { name: 'Golden Champion Trophy', color: '#ffd700', glow: '#ffaa00' },
    { name: 'Emerald Turf Cricket', color: '#00ff88', glow: '#00aa44' },
    { name: 'Electric Royal Blue', color: '#0066ff', glow: '#00ccff' },
    { name: 'Cyber Purple Lightning', color: '#9900ff', glow: '#cc33ff' },
    { name: 'Neon Sunset Orange', color: '#ff6600', glow: '#ff9933' },
    { name: 'Midnight Obsidian Black', color: '#1a1a1a', glow: '#00f3ff' },
    { name: 'Platinum Silver Bullet', color: '#e0e0e0', glow: '#ffffff' },
    { name: 'Neon Lime T20 Smash', color: '#00ff00', glow: '#66ff33' },
    { name: 'Magenta Super League', color: '#ff0066', glow: '#ff3399' },
    { name: 'Teal Ocean Wave', color: '#00cccc', glow: '#00ffff' },
    { name: 'Copper Bronze Heritage', color: '#b87333', glow: '#ff8000' },
    { name: 'Ice Blue Blizzard', color: '#99ffff', glow: '#0088ff' },
    { name: 'Toxic Radioactive Yellow', color: '#ccff00', glow: '#99cc00' },
    { name: 'Crimson Inferno', color: '#800000', glow: '#ff3300' },
    { name: 'Amethyst Sparkle', color: '#9933ff', glow: '#ff00ff' },
    { name: 'Titanium Steel Gray', color: '#708090', glow: '#00f3ff' },
    { name: 'Solar Flare Gold', color: '#ffcc00', glow: '#ff4500' },
  ];

  // Calculate maximum health limit based on 10-level tiers
  const calculateMaxLives = (levelNum: number) => {
    return Math.floor((levelNum - 1) / 10) + 1;
  };

  const initAudio = () => {
    if (!audioCtxRef.current && typeof window !== 'undefined') {
      audioCtxRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
    if (audioCtxRef.current && audioCtxRef.current.state === 'suspended') {
      audioCtxRef.current.resume();
    }
    return audioCtxRef.current;
  };

  useEffect(() => {
    setIsMounted(true);
    try {
      const savedHighest = localStorage.getItem('catch_star_highest_level');
      const savedCurrent = localStorage.getItem('catch_star_current_level');
      
      if (savedHighest) {
        const parsedHighest = parseInt(savedHighest, 10);
        if (!isNaN(parsedHighest)) {
          setHighestUnlockedLevel(parsedHighest);
        }
      }
      
      if (savedCurrent) {
        const parsedCurrent = parseInt(savedCurrent, 10);
        if (!isNaN(parsedCurrent)) {
          setCurrentLevel(parsedCurrent);
        }
      }
    } catch (e) {
      console.error('Failed to load progress', e);
    }
  }, []);

  useEffect(() => {
    if (!isMounted) return;
    try {
      localStorage.setItem('catch_star_highest_level', highestUnlockedLevel.toString());
      localStorage.setItem('catch_star_current_level', currentLevel.toString());
    } catch (e) {
      console.error('Failed to save progress', e);
    }
  }, [highestUnlockedLevel, currentLevel, isMounted]);

  useEffect(() => {
    if (gameState === 'playing') {
      // Start each stage with 0 health balance as requested
      setLives(0);
    }
  }, [gameState, currentLevel]);

  useEffect(() => {
    if (!isMounted) return;

    if (soundEnabled) {
      const chords = [
        [196.00, 246.94, 293.66, 369.99], 
        [220.00, 261.63, 329.63, 392.00], 
        [174.61, 220.00, 261.63, 329.63], 
        [164.81, 196.00, 246.94, 293.66]  
      ];
      let chordIdx = 0;

      const scheduleBgm = () => {
        const audioCtx = initAudio();
        if (!audioCtx) return;
        const now = audioCtx.currentTime;
        const currentChord = chords[chordIdx % chords.length];
        
        currentChord.forEach((freq) => {
          const osc = audioCtx.createOscillator();
          const gainNode = audioCtx.createGain();
          osc.connect(gainNode);
          gainNode.connect(audioCtx.destination);
          osc.type = 'sine';
          osc.frequency.setValueAtTime(freq, now);
          
          gainNode.gain.setValueAtTime(0, now);
          gainNode.gain.linearRampToValueAtTime(0.12, now + 2); 
          gainNode.gain.exponentialRampToValueAtTime(0.001, now + 6); 
          
          osc.start(now);
          osc.stop(now + 7);
        });

        currentChord.forEach((freq, i) => {
          const twinkleOsc = audioCtx.createOscillator();
          const twinkleGain = audioCtx.createGain();
          twinkleOsc.connect(twinkleGain);
          twinkleGain.connect(audioCtx.destination);
          
          twinkleOsc.type = 'triangle'; 
          twinkleOsc.frequency.setValueAtTime(freq * 2, now + i * 0.7);
          
          twinkleGain.gain.setValueAtTime(0, now + i * 0.7);
          twinkleGain.gain.linearRampToValueAtTime(0.08, now + i * 0.7 + 0.1); 
          twinkleGain.gain.exponentialRampToValueAtTime(0.001, now + i * 0.7 + 1.2);
          
          twinkleOsc.start(now + i * 0.7);
          twinkleOsc.stop(now + i * 0.7 + 1.5);
        });

        chordIdx++;
      };

      bgmIntervalRef.current = setInterval(scheduleBgm, 7000);
      scheduleBgm();
    } else {
      if (bgmIntervalRef.current) clearInterval(bgmIntervalRef.current);
    }

    return () => {
      if (bgmIntervalRef.current) clearInterval(bgmIntervalRef.current);
    };
  }, [soundEnabled, isMounted]);

  const playSound = (type: 'whoosh' | 'click' | 'win' | 'fall' | 'collect') => {
    if (!soundEnabled) return;
    try {
      const audioCtx = initAudio();
      if (!audioCtx) return;
      const osc = audioCtx.createOscillator();
      const gain = audioCtx.createGain();
      osc.connect(gain);
      gain.connect(audioCtx.destination);

      if (type === 'click') {
        osc.frequency.setValueAtTime(600, audioCtx.currentTime);
        gain.gain.setValueAtTime(0.9, audioCtx.currentTime); 
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.05);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.05);
      } else if (type === 'whoosh') {
        osc.type = 'sine';
        osc.frequency.setValueAtTime(280, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(140, audioCtx.currentTime + 0.3);
        gain.gain.setValueAtTime(0.9, audioCtx.currentTime); 
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.3);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.3);
      } else if (type === 'fall') {
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(300, audioCtx.currentTime);
        osc.frequency.linearRampToValueAtTime(100, audioCtx.currentTime + 0.4);
        gain.gain.setValueAtTime(0.5, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.4);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.4);
      } else if (type === 'win') {
        let now = audioCtx.currentTime;
        [400, 550, 700, 880].forEach((freq, idx) => {
          const o = audioCtx.createOscillator();
          const g = audioCtx.createGain();
          o.connect(g);
          g.connect(audioCtx.destination);
          o.frequency.setValueAtTime(freq, now + idx * 0.1);
          g.gain.setValueAtTime(0.9, now + idx * 0.1); 
          g.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.1 + 0.2);
          o.start(now + idx * 0.1);
          o.stop(now + idx * 0.1 + 0.2);
        });
      } else if (type === 'collect') {
        osc.frequency.setValueAtTime(880, audioCtx.currentTime);
        osc.frequency.exponentialRampToValueAtTime(1200, audioCtx.currentTime + 0.1);
        gain.gain.setValueAtTime(0.5, audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, audioCtx.currentTime + 0.1);
        osc.start();
        osc.stop(audioCtx.currentTime + 0.1);
      }
    } catch (e) {
      console.error(e);
    }
  };

  useEffect(() => {
    if (gameState !== 'playing') return;

    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = canvas.parentElement?.clientWidth || 400);
    let height = (canvas.height = canvas.parentElement?.clientHeight || 650);

    const levelDistance = 800 + (currentLevel - 1) * 100;
    const gravity = 0.5;
    const jumpStrength = -12.5;
    const padding = 24;
    const platformWidth = 80; 
    const platformHeight = 14;

    const maxLives = calculateMaxLives(currentLevel);

    let cameraY = 0;
    let lastLandedPlatform: any = null;
    let ball = {
      x: width / 2,
      y: height - 150,
      radius: 16,
      vx: 0,
      vy: 0,
      isGrounded: false,
    };

    const starLayers = [
      Array.from({ length: 80 }, () => ({ x: Math.random() * width, y: Math.random() * (levelDistance + height * 2) - levelDistance, size: 1, speed: 0.15, opacity: 0.3 + Math.random() * 0.3 })),
      Array.from({ length: 40 }, () => ({ x: Math.random() * width, y: Math.random() * (levelDistance + height * 2) - levelDistance, size: 2, speed: 0.4, opacity: 0.5 + Math.random() * 0.4 })),
      Array.from({ length: 20 }, () => ({ x: Math.random() * width, y: Math.random() * (levelDistance + height * 2) - levelDistance, size: 3, speed: 0.7, opacity: 0.7 + Math.random() * 0.3 }))
    ];

    const nebulae = Array.from({ length: 8 }, () => ({
      x: Math.random() * width,
      y: Math.random() * (levelDistance + height * 1.5) - levelDistance,
      radius: 180 + Math.random() * 220,
      color: ['rgba(75, 0, 130, 0.1)', 'rgba(0, 0, 255, 0.08)', 'rgba(255, 0, 255, 0.07)', 'rgba(0, 128, 128, 0.06)'][Math.floor(Math.random() * 4)]
    }));

    const galaxies = Array.from({ length: 4 }, () => ({
      x: Math.random() * width,
      y: Math.random() * (levelDistance + height) - levelDistance,
      size: 40 + Math.random() * 60,
      angle: Math.random() * Math.PI * 2,
      color: ['#4c1d95', '#1e3a8a', '#5b21b6'][Math.floor(Math.random() * 3)],
      rotSpeed: 0.002 + Math.random() * 0.005
    }));

    const smilingStars = Array.from({ length: 12 }, () => ({
      x: Math.random() * width,
      y: Math.random() * (levelDistance + height) - levelDistance,
      size: 8 + Math.random() * 6,
      angle: Math.random() * Math.PI * 2,
      rotSpeed: (Math.random() - 0.5) * 0.02,
      color: '#fbbf24'
    }));

    const cutePlanets = Array.from({ length: 6 }, () => ({
      x: Math.random() * width,
      y: Math.random() * (levelDistance + height) - levelDistance,
      radius: 12 + Math.random() * 8,
      color: ['#f87171', '#60a5fa', '#a78bfa', '#fb923c'][Math.floor(Math.random() * 4)],
      ringColor: 'rgba(255, 255, 255, 0.4)',
      angle: Math.random() * Math.PI * 2
    }));

    const crescentMoons = Array.from({ length: 5 }, () => ({
      x: Math.random() * width,
      y: Math.random() * (levelDistance + height) - levelDistance,
      radius: 10 + Math.random() * 5,
      angle: Math.random() * Math.PI * 2,
      rotSpeed: 0.005
    }));

    const asteroids = Array.from({ length: 12 }, () => ({
      x: Math.random() * width,
      y: Math.random() * (levelDistance + height) - levelDistance,
      size: 5 + Math.random() * 15,
      angle: Math.random() * Math.PI * 2,
      rotSpeed: (Math.random() - 0.5) * 0.04,
      vx: (Math.random() - 0.5) * 0.5,
      vy: (Math.random() - 0.5) * 0.5
    }));

    const celestialSun = { x: width * 0.85, y: -levelDistance * 0.6, radius: 50 };
    const celestialMoon = { x: width * 0.15, y: -levelDistance * 0.3, radius: 30 };
    const blackHole = { x: width * 0.5, y: -levelDistance * 0.8, angle: 0, size: 70 };

    const spaceUFO = { x: -60, y: height * 0.4, vx: 0.7, width: 36, height: 18 };
    const spaceRocket = { x: width + 60, y: -levelDistance * 0.5, vx: -1.2, vy: 0.3, size: 22 };
    const spaceSatellite = { x: -40, y: height * 0.7, vx: 0.4, angle: 0, rotSpeed: 0.008 };

    const shootingStar = { x: 0, y: 0, vx: 0, vy: 0, active: false, timer: 0 };

    const platforms: any[] = [];
    // Index 0 is the starting base platform
    platforms.push({ 
      x: width / 2 - platformWidth / 2, 
      y: height - 60, 
      w: platformWidth, 
      h: platformHeight, 
      vx: 1.8, 
      minX: padding, 
      maxX: width - platformWidth - padding,
      hasHeart: false
    });

    let currentY = height - 160;
    while (currentY > -levelDistance) {
      const minX = padding;
      const maxX = width - platformWidth - padding;
      const pX = Math.random() * (maxX - minX) + minX;
      const speed = 1.8 + Math.random() * 0.2;
      const pVx = Math.random() > 0.5 ? speed : -speed;
      // Initialize all with hasHeart: false first
      platforms.push({ x: pX, y: currentY, w: platformWidth, h: platformHeight, vx: pVx, minX, maxX, hasHeart: false });
      currentY -= Math.floor(Math.random() * 25) + 55;
    }

    // Fixed placement of exactly maxLives hearts on random platforms (excluding base)
    if (platforms.length > 1) {
      const availableIndices = Array.from({ length: platforms.length - 1 }, (_, i) => i + 1);
      let heartsPlaced = 0;
      while (heartsPlaced < maxLives && availableIndices.length > 0) {
        const randomIndex = Math.floor(Math.random() * availableIndices.length);
        const platformIndex = availableIndices.splice(randomIndex, 1)[0];
        platforms[platformIndex].hasHeart = true;
        heartsPlaced++;
      }
    }

    const goalStar = { x: width / 2 - 30, y: -levelDistance - 120, size: 60 };

    const handleInput = (e: any) => {
      e.preventDefault();
      initAudio();
      if (ball.isGrounded) {
        ball.vy = jumpStrength;
        ball.isGrounded = false;
        playSound('whoosh');
      }
    };

    canvas.addEventListener('pointerdown', handleInput);

    const update = () => {
      ball.vy += gravity;
      ball.y += ball.vy;
      ball.x += ball.vx;

      const targetCameraY = ball.y - height / 2;
      cameraY += (targetCameraY - cameraY) * 0.1;

      platforms.forEach(p => {
        p.x += p.vx;
        if (p.x <= p.minX || p.x >= p.maxX) p.vx *= -1;
      });

      ball.isGrounded = false;
      ball.vx = 0;
      platforms.forEach(p => {
        if (
          ball.vy > 0 &&
          ball.x >= p.x - 15 &&
          ball.x <= p.x + p.w + 15 &&
          ball.y + ball.radius >= p.y &&
          ball.y + ball.radius <= p.y + 25
        ) {
          ball.y = p.y - ball.radius;
          ball.vy = 0;
          ball.isGrounded = true;
          ball.vx = p.vx;
          lastLandedPlatform = p;

          if (p.hasHeart) {
            p.hasHeart = false;
            // Update health but respect the max lives tier limit
            setLives(l => Math.min(l + 1, maxLives));
            playSound('collect');
          }
        }
      });

      if (ball.y > height + cameraY + 300) {
        playSound('fall');
        // Respawn on the exact platform the ball last stood on, not a random
        // camera-relative platform. This prevents the ball appearing to vanish.
        const respawnPlatform = lastLandedPlatform || platforms[0];
        setLives(prevLives => {
          const updatedLives = prevLives - 1;
          if (updatedLives >= 0) {
            ball.x = respawnPlatform.x + respawnPlatform.w / 2;
            ball.y = respawnPlatform.y - ball.radius;
            ball.vx = 0;
            ball.vy = 0;
            ball.isGrounded = true;
            cameraY = ball.y - height / 2;
            return updatedLives;
          } else {
            const base = platforms[0];
            ball.x = base.x + base.w / 2;
            ball.y = base.y - ball.radius;
            ball.vx = 0;
            ball.vy = 0;
            ball.isGrounded = true;
            cameraY = 0;
            lastLandedPlatform = base;
            setGameState('home');
            return 0;
          }
        });
      }

      if (
        ball.x >= goalStar.x - 10 && ball.x <= goalStar.x + goalStar.size + 10 &&
        ball.y >= goalStar.y - 10 && ball.y <= goalStar.y + goalStar.size + 10
      ) {
        playSound('win');
        if (currentLevel >= highestUnlockedLevel) {
          setHighestUnlockedLevel(currentLevel + 1);
        }
        setGameState('victory');
      }

      asteroids.forEach(a => {
        a.x += a.vx;
        a.y += a.vy;
        a.angle += a.rotSpeed;
      });

      galaxies.forEach(g => {
        g.angle += g.rotSpeed;
      });

      smilingStars.forEach(s => {
        s.angle += s.rotSpeed;
      });

      crescentMoons.forEach(m => {
        m.angle += m.rotSpeed;
      });

      blackHole.angle += 0.025;

      spaceUFO.x += spaceUFO.vx;
      if (spaceUFO.x > width + 100) spaceUFO.x = -100;

      spaceRocket.x += spaceRocket.vx;
      spaceRocket.y += spaceRocket.vy;
      if (spaceRocket.x < -100) {
        spaceRocket.x = width + 100;
        spaceRocket.y = -levelDistance * (0.1 + Math.random() * 0.8);
      }

      spaceSatellite.x += spaceSatellite.vx;
      spaceSatellite.angle += spaceSatellite.rotSpeed;
      if (spaceSatellite.x > width + 100) spaceSatellite.x = -100;

      if (!shootingStar.active && Math.random() < 0.007) {
        shootingStar.active = true;
        shootingStar.x = Math.random() * width;
        shootingStar.y = cameraY - 150;
        shootingStar.vx = (Math.random() > 0.5 ? 6 : -6);
        shootingStar.vy = 12 + Math.random() * 6;
        shootingStar.timer = 50;
      }
      if (shootingStar.active) {
        shootingStar.x += shootingStar.vx;
        shootingStar.y += shootingStar.vy;
        shootingStar.timer--;
        if (shootingStar.timer <= 0) shootingStar.active = false;
      }
    };

    const draw = () => {
      ctx.clearRect(0, 0, width, height);

      const spaceGrad = ctx.createLinearGradient(0, 0, 0, height);
      spaceGrad.addColorStop(0, '#020010');
      spaceGrad.addColorStop(0.5, '#0a0624');
      spaceGrad.addColorStop(1, '#180d32');
      ctx.fillStyle = spaceGrad;
      ctx.fillRect(0, 0, width, height);

      ctx.save();
      ctx.translate(0, -cameraY);

      nebulae.forEach(n => {
        const grad = ctx.createRadialGradient(n.x, n.y, 0, n.x, n.y, n.radius);
        grad.addColorStop(0, n.color);
        grad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.radius, 0, Math.PI * 2);
        ctx.fill();
      });

      galaxies.forEach(g => {
        ctx.save();
        ctx.translate(g.x, g.y);
        ctx.rotate(g.angle);
        const galGrad = ctx.createRadialGradient(0, 0, 0, 0, 0, g.size);
        galGrad.addColorStop(0, g.color);
        galGrad.addColorStop(0.6, 'rgba(91, 33, 182, 0.2)');
        galGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
        ctx.fillStyle = galGrad;
        ctx.beginPath();
        ctx.ellipse(0, 0, g.size, g.size * 0.4, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.restore();
      });

      const sunGrad = ctx.createRadialGradient(celestialSun.x, celestialSun.y, 5, celestialSun.x, celestialSun.y, celestialSun.radius);
      sunGrad.addColorStop(0, '#ffffff');
      sunGrad.addColorStop(0.3, '#ffdd00');
      sunGrad.addColorStop(1, 'rgba(255, 120, 0, 0)');
      ctx.fillStyle = sunGrad;
      ctx.beginPath();
      ctx.arc(celestialSun.x, celestialSun.y, celestialSun.radius, 0, Math.PI * 2);
      ctx.fill();

      ctx.save();
      ctx.shadowColor = '#94a3b8';
      ctx.shadowBlur = 15;
      ctx.fillStyle = '#e2e8f0';
      ctx.beginPath();
      ctx.arc(celestialMoon.x, celestialMoon.y, celestialMoon.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;
      ctx.fillStyle = '#cbd5e1'; 
      ctx.beginPath();
      ctx.arc(celestialMoon.x - 8, celestialMoon.y - 5, 5, 0, Math.PI * 2);
      ctx.arc(celestialMoon.x + 6, celestialMoon.y + 7, 6, 0, Math.PI * 2);
      ctx.arc(celestialMoon.x - 5, celestialMoon.y + 10, 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      ctx.save();
      ctx.translate(blackHole.x, blackHole.y);
      ctx.rotate(blackHole.angle);
      const bhGrad = ctx.createRadialGradient(0, 0, 15, 0, 0, blackHole.size);
      bhGrad.addColorStop(0, '#000000');
      bhGrad.addColorStop(0.2, '#3b0764');
      bhGrad.addColorStop(0.5, '#db2777');
      bhGrad.addColorStop(1, 'rgba(0, 0, 0, 0)');
      ctx.fillStyle = bhGrad;
      ctx.beginPath();
      ctx.arc(0, 0, blackHole.size, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      starLayers.forEach((layer) => {
        ctx.save();
        const parallaxOffset = cameraY * (layer[0].speed - 0.75);
        ctx.translate(0, parallaxOffset);
        layer.forEach(s => {
          ctx.globalAlpha = s.opacity;
          ctx.fillStyle = '#ffffff';
          ctx.fillRect(s.x, s.y, s.size, s.size);
        });
        ctx.restore();
      });

      smilingStars.forEach(s => {
        ctx.save();
        ctx.translate(s.x, s.y);
        ctx.rotate(s.angle);
        ctx.fillStyle = s.color;
        ctx.beginPath();
        for (let i = 0; i < 5; i++) {
          ctx.lineTo(Math.cos((18 + i * 72) * Math.PI / 180) * s.size, Math.sin((18 + i * 72) * Math.PI / 180) * s.size);
          ctx.lineTo(Math.cos((54 + i * 72) * Math.PI / 180) * (s.size / 2.2), Math.sin((54 + i * 72) * Math.PI / 180) * (s.size / 2.2));
        }
        ctx.closePath();
        ctx.fill();
        ctx.fillStyle = '#000';
        ctx.beginPath();
        ctx.arc(-s.size / 4, -s.size / 8, 1.2, 0, Math.PI * 2);
        ctx.arc(s.size / 4, -s.size / 8, 1.2, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#000';
        ctx.lineWidth = 1;
        ctx.beginPath();
        ctx.arc(0, s.size / 10, s.size / 4, 0.2, Math.PI - 0.2);
        ctx.stroke();
        ctx.restore();
      });

      cutePlanets.forEach(p => {
        ctx.save();
        ctx.translate(p.x, p.y);
        ctx.rotate(p.angle);
        ctx.fillStyle = p.color;
        ctx.beginPath();
        ctx.arc(0, 0, p.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = p.ringColor;
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.ellipse(0, 0, p.radius * 1.8, p.radius * 0.4, Math.PI / 8, 0, Math.PI * 2);
        ctx.stroke();
        ctx.restore();
      });

      crescentMoons.forEach(m => {
        ctx.save();
        ctx.translate(m.x, m.y);
        ctx.rotate(m.angle);
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.arc(0, 0, m.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalCompositeOperation = 'destination-out';
        ctx.beginPath();
        ctx.arc(m.radius * 0.4, -m.radius * 0.4, m.radius, 0, Math.PI * 2);
        ctx.fill();
        ctx.globalCompositeOperation = 'source-over';
        ctx.restore();
      });

      ctx.fillStyle = '#94a3b8'; 
      ctx.fillRect(spaceSatellite.x, spaceSatellite.y, 16, 10);
      ctx.fillStyle = '#38bdf8';
      ctx.fillRect(spaceSatellite.x - 10, spaceSatellite.y + 2, 8, 6);
      ctx.fillRect(spaceSatellite.x + 18, spaceSatellite.y + 2, 8, 6);

      ctx.save(); 
      ctx.translate(spaceRocket.x, spaceRocket.y);
      ctx.fillStyle = '#ef4444';
      ctx.fillRect(18, 5, 10, 5);
      ctx.fillStyle = '#f8fafc';
      ctx.beginPath();
      ctx.moveTo(20, 0);
      ctx.lineTo(0, 7);
      ctx.lineTo(20, 14);
      ctx.closePath();
      ctx.fill();
      ctx.restore();

      ctx.fillStyle = '#475569'; 
      ctx.beginPath();
      ctx.ellipse(spaceUFO.x + 18, spaceUFO.y + 9, 18, 7, 0, 0, Math.PI * 2);
      ctx.fill();
      ctx.fillStyle = '#06b6d4';
      ctx.beginPath();
      ctx.arc(spaceUFO.x + 18, spaceUFO.y + 7, 7, Math.PI, 0);
      ctx.fill();

      if (shootingStar.active) {
        ctx.shadowBlur = 20;
        ctx.shadowColor = '#fff';
        ctx.strokeStyle = `rgba(255, 255, 255, ${shootingStar.timer / 50})`;
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(shootingStar.x, shootingStar.y);
        ctx.lineTo(shootingStar.x - shootingStar.vx * 4, shootingStar.y - shootingStar.vy * 4);
        ctx.stroke();
        ctx.shadowBlur = 0;
      }

      asteroids.forEach(a => {
        ctx.save();
        ctx.translate(a.x, a.y);
        ctx.rotate(a.angle);
        ctx.fillStyle = '#4b5563';
        ctx.beginPath();
        for (let i = 0; i < 6; i++) {
          const r = a.size * (0.8 + Math.random() * 0.4);
          const x = Math.cos(i * Math.PI / 3) * r;
          const y = Math.sin(i * Math.PI / 3) * r;
          if (i === 0) ctx.moveTo(x, y);
          else ctx.lineTo(x, y);
        }
        ctx.closePath();
        ctx.fill();
        ctx.restore();
      });

      ctx.shadowColor = '#ffe100';
      ctx.shadowBlur = 40;
      const starGrad = ctx.createRadialGradient(goalStar.x + goalStar.size / 2, goalStar.y + goalStar.size / 2, 5, goalStar.x + goalStar.size / 2, goalStar.y + goalStar.size / 2, goalStar.size / 2);
      starGrad.addColorStop(0, '#ffffff');
      starGrad.addColorStop(0.3, '#ffe100');
      starGrad.addColorStop(1, '#ffb700');
      ctx.fillStyle = starGrad;
      ctx.beginPath();
      ctx.arc(goalStar.x + goalStar.size / 2, goalStar.y + goalStar.size / 2, goalStar.size / 2, 0, Math.PI * 2);
      ctx.fill();
      ctx.shadowBlur = 0;

      platforms.forEach((p, idx) => {
        const isSpecial = idx % 2 === 0;
        ctx.shadowColor = isSpecial ? '#ff0055' : '#00f3ff';
        ctx.shadowBlur = 20;
        ctx.fillStyle = isSpecial ? '#ff3366' : '#00d2ff';
        ctx.beginPath();
        if ((ctx as any).roundRect) (ctx as any).roundRect(p.x, p.y, p.w, p.h, 7);
        else ctx.rect(p.x, p.y, p.w, p.h);
        ctx.fill();
        ctx.shadowBlur = 0;

        if (p.hasHeart) {
          ctx.save();
          ctx.translate(p.x + p.w / 2, p.y - 18);
          ctx.fillStyle = "#ff3366";
          ctx.shadowColor = "#ff0055";
          ctx.shadowBlur = 15;
          ctx.beginPath();
          const size = 8;
          ctx.moveTo(0, 0);
          ctx.bezierCurveTo(-size, -size, -size * 2, size / 2, 0, size * 1.5);
          ctx.bezierCurveTo(size * 2, size / 2, size, -size, 0, 0);
          ctx.fill();
          ctx.restore();
        }
      });

      const colorData = ballColors.find(c => c.color === selectedColor) || ballColors[0];
      
      ctx.save();
      ctx.shadowColor = colorData.glow;
      ctx.shadowBlur = 35;
      ctx.beginPath();
      ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
      ctx.fill();
      ctx.restore();

      ctx.strokeStyle = '#ffffff';
      ctx.lineWidth = 2.5;
      ctx.beginPath();
      ctx.arc(ball.x, ball.y, ball.radius, 0, Math.PI * 2);
      ctx.stroke();

      const ballGrad = ctx.createRadialGradient(
        ball.x - ball.radius * 0.4, 
        ball.y - ball.radius * 0.4, 
        2, 
        ball.x, 
        ball.y, 
        ball.radius
      );
      ballGrad.addColorStop(0, '#ffffff');
      ballGrad.addColorStop(0.4, colorData.color);
      ballGrad.addColorStop(1, '#000000');
      
      ctx.fillStyle = ballGrad;
      ctx.beginPath();
      ctx.arc(ball.x, ball.y, ball.radius - 1, 0, Math.PI * 2);
      ctx.fill();

      ctx.strokeStyle = 'rgba(255, 255, 255, 0.9)';
      ctx.lineWidth = 1.5;
      ctx.beginPath(); 
      ctx.arc(ball.x, ball.y, ball.radius - 4, 0.25, Math.PI - 0.25);
      ctx.stroke();
      ctx.beginPath(); 
      ctx.arc(ball.x, ball.y - 2.5, ball.radius - 4, 0.25, Math.PI - 0.25);
      ctx.stroke();
      ctx.beginPath(); 
      ctx.arc(ball.x, ball.y + 2.5, ball.radius - 4, 0.25, Math.PI - 0.25);
      ctx.stroke();

      ctx.restore();
    };

    const loop = () => {
      update();
      draw();
      animationFrameId = requestAnimationFrame(loop);
    };

    loop();

    return () => {
      canvas.removeEventListener('pointerdown', handleInput);
      cancelAnimationFrame(animationFrameId);
    };
  }, [gameState, currentLevel, selectedColor]);

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-slate-950 text-white select-none p-4 font-body">
      <div className="relative w-full max-w-md h-[700px] bg-slate-900 border-4 border-slate-800 rounded-3xl overflow-hidden shadow-2xl flex flex-col">
        
        {gameState === 'playing' && (
          <div className="relative w-full h-full">
            <div className="absolute top-4 left-4 right-4 flex justify-between items-center z-20">
              <button
                onClick={() => { initAudio(); playSound('click'); setGameState('home'); }}
                className="bg-slate-800/90 backdrop-blur border border-slate-700 px-4 py-2 rounded-2xl text-sm font-bold shadow-md hover:bg-slate-700 transition-colors text-white"
              >
                🏠 Home
              </button>
              
              <div className="flex items-center gap-3">
                <div className="bg-rose-950/90 backdrop-blur border border-rose-500/40 px-3 py-2 rounded-2xl text-sm font-bold text-rose-400 flex items-center gap-1.5 shadow-md shadow-rose-950/40">
                  ❤️ <span className="font-mono">{lives}</span>
                  <span className="text-[10px] text-rose-300 opacity-70"> / {calculateMaxLives(currentLevel)}</span>
                </div>
                <div className="bg-slate-800/90 backdrop-blur border border-slate-700 px-4 py-2 rounded-2xl text-sm font-bold text-cyan-400 tracking-wider shadow-md">
                  STAGE {currentLevel}
                </div>
              </div>
            </div>
            <canvas ref={canvasRef} className="w-full h-full block cursor-pointer touch-none" />
          </div>
        )}

        {gameState === 'home' && (
          <div className="flex flex-col items-center justify-center h-full p-6 text-center bg-gradient-to-b from-slate-900 via-indigo-950 to-slate-950">
            <h1 className="text-4xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-indigo-400 mb-2 drop-shadow-md">
              Catch The Star Glow
            </h1>
            <p className="text-slate-400 text-sm font-medium tracking-wide mb-8">Neon Cricket Arcade Adventure</p>
            <div className="flex flex-col gap-4 w-full max-w-xs">
              <button 
                onClick={() => { 
                  initAudio(); 
                  playSound('click'); 
                  setGameState('playing'); 
                }} 
                className="py-4 bg-gradient-to-r from-cyan-500 to-blue-600 rounded-2xl font-bold text-lg shadow-lg hover:opacity-95 transition-opacity text-white"
              >
                Start Game
              </button>
              <button onClick={() => { initAudio(); playSound('click'); setGameState('levels'); }} className="py-3 bg-slate-800 border border-slate-700 rounded-2xl font-semibold shadow hover:bg-slate-700/80 transition-colors text-white">Select Level</button>
              <button onClick={() => { initAudio(); playSound('click'); setGameState('shop'); }} className="py-3 bg-slate-800 border border-slate-700 rounded-2xl font-semibold shadow hover:bg-slate-700/80 transition-colors text-white">🛒 Ball Shop</button>
              <button onClick={() => { initAudio(); playSound('click'); setGameState('settings'); }} className="py-3 bg-slate-800 border border-slate-700 rounded-2xl font-semibold shadow hover:bg-slate-700/80 transition-colors text-white">Settings</button>
            </div>
          </div>
        )}

        {gameState === 'levels' && (
          <div className="flex flex-col h-full p-6 bg-slate-950">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-cyan-400">Select Level</h2>
              <button onClick={() => { initAudio(); playSound('click'); setGameState('home'); }} className="bg-slate-800 border border-slate-700 text-white px-4 py-1.5 rounded-xl text-sm font-semibold shadow hover:bg-slate-700 transition-colors">Back</button>
            </div>
            <div className="grid grid-cols-4 gap-3 overflow-y-auto flex-1 pr-1">
              {Array.from({ length: 40 }, (_, i) => i + 1).map((lvl) => {
                const unlocked = lvl <= highestUnlockedLevel;
                return (
                  <button 
                    key={lvl} 
                    disabled={!unlocked} 
                    onClick={() => { 
                      if (unlocked) { 
                        initAudio(); 
                        playSound('click'); 
                        setCurrentLevel(lvl); 
                        setGameState('playing'); 
                      } 
                    }} 
                    className={`h-16 rounded-2xl font-bold text-lg flex items-center justify-center border transition-all ${unlocked ? 'bg-slate-800 border-cyan-500 text-cyan-300 hover:bg-cyan-950/40 shadow-sm' : 'bg-slate-900/50 border-slate-800/80 text-slate-600'}`}
                  >
                    {lvl}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {gameState === 'shop' && (
          <div className="flex flex-col h-full p-6 bg-slate-950">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold text-cyan-400">Cricket Ball Shop</h2>
              <button onClick={() => { initAudio(); playSound('click'); setGameState('home'); }} className="bg-slate-800 border border-slate-700 text-white px-4 py-1.5 rounded-xl text-sm font-semibold shadow hover:bg-slate-700 transition-colors">Back</button>
            </div>
            <div className="flex flex-col gap-3 overflow-y-auto flex-1 pr-1">
              {ballColors.map((item) => {
                const active = selectedColor === item.color;
                return (
                  <div key={item.color} onClick={() => { initAudio(); playSound('click'); setSelectedColor(item.color); }} className={`flex items-center justify-between p-4 rounded-2xl border transition-all cursor-pointer ${active ? 'bg-cyan-950/50 border-cyan-400 shadow-md' : 'bg-slate-900 border-slate-800 hover:bg-slate-800/60'}`}>
                    <div className="flex items-center gap-4">
                      <div className="w-10 h-10 rounded-full border border-white/40 overflow-hidden relative" style={{ 
                        background: `radial-gradient(circle at 30% 30%, #ffffff 0%, ${item.color} 50%, #000000 100%)`,
                        boxShadow: `0 0 14px ${item.glow}` 
                      }}>
                        <div className="absolute top-1/2 left-0 w-full h-[2px] bg-white/50 -translate-y-1/2" />
                        <div className="absolute top-[calc(1/2*100%-3px)] left-0 w-full h-[1px] bg-white/30" />
                        <div className="absolute top-[calc(1/2*100%+3px)] left-0 w-full h-[1px] bg-white/30" />
                      </div>
                      <span className="font-bold text-slate-100 text-sm truncate max-w-[150px]">{item.name}</span>
                    </div>
                    <span className={`text-xs font-bold px-3 py-1.5 rounded-xl transition-colors ${active ? 'bg-cyan-500 text-slate-950 shadow-sm' : 'bg-slate-800 text-slate-400'}`}>{active ? 'Equipped' : 'Select'}</span>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {gameState === 'settings' && (
          <div className="flex flex-col h-full p-6 bg-slate-950">
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-bold text-cyan-400">Settings</h2>
              <button onClick={() => { initAudio(); playSound('click'); setGameState('home'); }} className="bg-slate-800 border border-slate-700 text-white px-4 py-1.5 rounded-xl text-sm font-semibold shadow hover:bg-slate-700 transition-colors">Back</button>
            </div>
            <div className="flex items-center justify-between bg-slate-900 p-5 rounded-2xl border border-slate-800 shadow-sm">
              <span className="font-semibold text-slate-200">Sound & BGM</span>
              <button onClick={() => setSoundEnabled(!soundEnabled)} className={`px-5 py-2 rounded-xl font-bold text-sm shadow-sm transition-all ${soundEnabled ? 'bg-cyan-500 text-slate-950 hover:bg-cyan-400' : 'bg-slate-800 text-slate-400 hover:bg-slate-700'}`}>{soundEnabled ? 'ON' : 'OFF'}</button>
            </div>
            <button 
              onClick={() => {
                if (confirm('Reset all progress?')) {
                  localStorage.clear();
                  window.location.reload();
                }
              }}
              className="mt-auto py-3 bg-destructive/20 border border-destructive/50 text-destructive rounded-2xl font-bold text-sm hover:bg-destructive/30 transition-colors"
            >
              Reset Progress
            </button>
          </div>
        )}

        {gameState === 'victory' && (
          <div className="flex flex-col items-center justify-center h-full p-6 text-center bg-slate-950/90 backdrop-blur-md">
            <h2 className="text-3xl font-extrabold text-yellow-400 mb-2 drop-shadow-sm">🎉 Stage Cleared!</h2>
            <p className="text-slate-300 text-sm mb-8 font-medium">Ready for the next challenge?</p>
            <div className="flex flex-col gap-4 w-full max-w-xs">
              <button 
                onClick={() => { 
                  initAudio(); 
                  playSound('click'); 
                  setCurrentLevel(prev => prev + 1); 
                  setGameState('playing'); 
                }} 
                className="py-4 bg-gradient-to-r from-yellow-400 to-amber-500 text-slate-950 rounded-2xl font-bold text-lg shadow-lg hover:brightness-105 transition-all"
              >
                Next Level
              </button>
              <button onClick={() => { initAudio(); playSound('click'); setGameState('home'); }} className="py-3 bg-slate-800 border border-slate-700 text-white rounded-2xl font-semibold shadow hover:bg-slate-700 transition-colors">Main Menu</button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
