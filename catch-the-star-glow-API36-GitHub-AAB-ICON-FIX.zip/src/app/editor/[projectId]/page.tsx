export function generateStaticParams() {
  // Static export requires at least one concrete path for this dynamic route.
  // Keep the existing placeholder page unchanged while allowing the build to complete.
  return [{ projectId: 'default' }];
}

export default function EditorPage() {
  return (
    <div className="flex h-screen items-center justify-center">
      <h1 className="text-2xl font-bold">Editor Cleared</h1>
    </div>
  );
}
