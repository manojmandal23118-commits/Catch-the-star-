'use server';

import { adjustOnionSkinFrames, type AdjustOnionSkinInput } from '@/ai/flows/dynamic-onion-skin';

export async function getOnionSkinSuggestion(input: AdjustOnionSkinInput) {
  try {
    const result = await adjustOnionSkinFrames(input);
    return { success: true, data: result };
  } catch (error) {
    console.error('AI Error:', error);
    if (error instanceof Error) {
        return { success: false, error: `Failed to get suggestion from AI: ${error.message}` };
    }
    return { success: false, error: 'An unknown error occurred while getting AI suggestion.' };
  }
}
