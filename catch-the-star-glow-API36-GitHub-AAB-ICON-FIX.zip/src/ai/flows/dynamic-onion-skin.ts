'use server';

/**
 * @fileOverview AI flows have been cleared.
 */

export async function adjustOnionSkinFrames(input: any): Promise<any> {
  return { previousFrames: 2, nextFrames: 2 };
}
