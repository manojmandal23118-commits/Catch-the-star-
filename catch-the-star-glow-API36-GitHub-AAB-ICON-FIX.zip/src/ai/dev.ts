import { config } from 'dotenv';
config();

import '@/ai/flows/dynamic-onion-skin.ts';