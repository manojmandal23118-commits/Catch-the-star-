export default function EditorPage() {
  return (
    <div className="flex h-screen items-center justify-center">
      <h1 className="text-2xl font-bold">Editor Cleared</h1>
    </div>
  );
}
